using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public class Script : ScriptBase
{
    public override async Task<HttpResponseMessage> ExecuteAsync()
    {
        // Read request body
        var bodyText = await this.Context.Request.Content.ReadAsStringAsync().ConfigureAwait(false);

        if (string.IsNullOrWhiteSpace(bodyText))
            return JsonError(HttpStatusCode.BadRequest, "Empty request body.");

        // Parse JSON
        JToken root;
        try
        {
            root = JToken.Parse(bodyText);
        }
        catch (JsonReaderException)
        {
            return JsonError(HttpStatusCode.BadRequest, "Invalid JSON in request body.");
        }

        // Extract inputs
        var formDefinition = root["formDefinitionJSON"] as JObject;
        var responsesObject = root["responsesJSON"]       as JObject;

        if (formDefinition == null || responsesObject == null)
        {
            return JsonError(
                HttpStatusCode.BadRequest,
                "Missing or invalid input. Provide 'formDefinitionJSON' (object) and 'responsesJSON' (object)."
            );
        }

        // Convert responses into array with sort order
        var answersArray = new JArray();
        int sortOrder = 1;

        foreach (var prop in responsesObject.Properties())
        {
            answersArray.Add(new JObject
            {
                ["component_id"] = prop.Name,
                ["response"] = prop.Value,
                ["sort_order"] = sortOrder++
            });
        }

        // Build lookup of components keyed by _id (first one wins)
        var componentLookup = new Dictionary<string, JObject>(StringComparer.OrdinalIgnoreCase);

        foreach (var token in formDefinition.Descendants())
        {
            if (token is JObject o &&
                string.Equals(o["collection"]?.ToString(), "components", StringComparison.OrdinalIgnoreCase))
            {
                var id = o["_id"]?.ToString();

                if (!string.IsNullOrWhiteSpace(id) && !componentLookup.ContainsKey(id))
                {
                    componentLookup[id] = o;
                }
            }
        }
        
        // Enrich responses
        var enriched = new JArray();

        foreach (var a in answersArray)
        {
            if (a is not JObject ans) continue;

            var qid = ans["component_id"]?.ToString();
            componentLookup.TryGetValue(qid ?? string.Empty, out var comp);

            var component_hint   = comp?["hint"]?.ToString();
            var component_name   = comp?["name"]?.ToString();
            var component_type   = comp?["_type"]?.ToString() ?? "unknown";
            var component_uuid   = comp?["_uuid"]?.ToString();
            var component_legend = comp?["legend"]?.ToString();
            var component_label  = comp?["label"]?.ToString();

            // Build final row
            var row = new JObject
            {
                ["component_id"] = ans["component_id"],
                ["component_hint"] = component_hint,
                ["component_name"] = component_name,
                ["component_type"] = component_type,
                ["component_uuid"] = component_uuid,
                ["component_legend"] = component_legend,
                ["component_label"] = component_label, 
                ["response"]     = ans["response"],
                ["sort_order"]  = ans["sort_order"],
            };

            // Only for radio-type questions, find the item_uuid & item_label
            if (string.Equals(component_type, "radios", StringComparison.OrdinalIgnoreCase))
            {
                // Normalize response to a string
                string responseString = ans["response"]?.ToString()?.Trim();

                if (!string.IsNullOrWhiteSpace(responseString))
                {
                    var items = comp?["items"] as JArray;
                    if (items != null)
                    {
                        JObject matchedItem = null;

                        // Match only by item.label == response (case-insensitive)
                        foreach (var it in items)
                        {
                            if (it is JObject io)
                            {
                                var label = io["label"]?.ToString()?.Trim();
                                if (!string.IsNullOrEmpty(label) &&
                                    string.Equals(label, responseString, StringComparison.OrdinalIgnoreCase))
                                {
                                    matchedItem = io;
                                    break;
                                }
                            }
                        }

                        if (matchedItem != null)
                        {
                            row["item_uuid"]  = matchedItem["_uuid"]?.ToString();
                            row["item_label"] = matchedItem["label"]?.ToString();
                        }
                    }
                }
            };
            enriched.Add(row);
        }

        // Return JSON (fully qualify formatting to avoid ambiguity)
        var ok = new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = CreateJsonContent(enriched.ToString(Newtonsoft.Json.Formatting.None))
        };
        return ok;
    }

    private HttpResponseMessage JsonError(HttpStatusCode status, string message)
    {
        var err = new JObject { ["error"] = message };
        return new HttpResponseMessage(status)
        {
            Content = CreateJsonContent(err.ToString(Newtonsoft.Json.Formatting.None))
        };
    }
}