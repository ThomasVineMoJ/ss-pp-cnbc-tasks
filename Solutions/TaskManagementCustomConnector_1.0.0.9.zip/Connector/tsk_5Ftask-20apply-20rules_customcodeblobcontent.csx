public class Script : ScriptBase
{
    public override async Task<HttpResponseMessage> ExecuteAsync()
    {
        switch (this.Context.OperationId)
        {
            case "ApplyRules":
                return await this.ApplyRules().ConfigureAwait(false);

            case "GetCaseNumbers":
                return await this.GetCaseNumbers().ConfigureAwait(false);

            case "RouteFormTaskToQueue":
                return await this.RouteFormTaskToQueue().ConfigureAwait(false);

            // Handle an invalid operation ID
            default:
                return new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    Content = CreateJsonContent($"Unknown operation ID '{this.Context.OperationId}'")
                };
        }
    }

    private class Rule
    {
        // inputs
        [JsonProperty("ruleName")]
        public string RuleName { get; set; }
        [JsonProperty("queueId")]
        public string QueueID { get; set; }
        [JsonProperty("mustHave")]
        public string MustHave { get; set; }
        [JsonProperty("checkAtttachments")]
        public bool CheckAttachments { get; set; }
        [JsonProperty("keywords")]
        public List<string> Keywords { get; set; }
        [JsonProperty("regexPattern")]
        public string RegexInput { get; set; }

        // private 
        private string textToCheck;
        private bool hasAttachments;

        public bool EvaluateRule(string inputTextToCheck, bool inputHasAttachments, out string keywordFound)
        {
            // set inputs
            textToCheck = inputTextToCheck.ToLower();
            hasAttachments = inputHasAttachments;
            var keyFound = KeywordSearch(out keywordFound);

            return (MustHaveSearch() & keyFound & RegexSearch() & AttachmentSearch());
        }

        private bool MustHaveSearch()
        {
            return string.IsNullOrEmpty(MustHave) || textToCheck.Contains(MustHave.ToLower());
        }

        private bool KeywordSearch(out string keywordFound)
        {
            keywordFound = null;
            if (Keywords == null || !Keywords.Any())
            {
                return true; // No keywords to search for, so return true
            }

            foreach (string word in Keywords)
            {
                if (textToCheck.Contains(word.ToLower()))
                {
                    keywordFound = word; 
                    return true;
                }
            }
            return false;
        }

        private bool RegexSearch()
        {
            if (string.IsNullOrEmpty(RegexInput))
            {
                return true;
            }
            else
            {
                var rx = new Regex(RegexInput);
                return rx.IsMatch(textToCheck.ToUpper());
            }
        }

        private bool AttachmentSearch()
        {
            return !CheckAttachments || hasAttachments;
        }

    }

    // Apply Routing Rules Operation
    private async Task<HttpResponseMessage> ApplyRules()
    {
        
        const string RuleName = "RuleName";
        const string QueueID = "QueueID";
        const string KeywordFound = "KeywordFound";

        HttpResponseMessage response;

        JObject output = new JObject
        {
            [RuleName] = "No rule found",
            [QueueID] = null,
            [KeywordFound] = null
        };

        var contentAsString = await this.Context.Request.Content.ReadAsStringAsync().ConfigureAwait(false);

        // Parse as JSON object
        var contentAsJson = JObject.Parse(contentAsString);

        var textToCheck = (string)contentAsJson["email"]["textToSearch"];
        var hasAttachments = (bool)contentAsJson["email"]["hasAttachments"];

        foreach (JObject item in contentAsJson["rules"])
        {
            Rule rule = item.ToObject<Rule>();
            bool ruleApplies = rule.EvaluateRule(textToCheck, hasAttachments, out string keywordFound);

            if (ruleApplies)
            {
                output[RuleName] = rule.RuleName;
                output[QueueID] = rule.QueueID;
                output[KeywordFound] = keywordFound;
                break;
            }

        }

        response = new HttpResponseMessage(HttpStatusCode.OK);
        response.Content = CreateJsonContent(output.ToString());
        return response;
    }

    // Get Case Numbers Operation
    private async Task<HttpResponseMessage> GetCaseNumbers()
    {
        HttpResponseMessage response;

        var contentAsString = await this.Context.Request.Content.ReadAsStringAsync().ConfigureAwait(false);
        var contentAsJson = JObject.Parse(contentAsString);

        var textToSearch = (string)contentAsJson["textToSearch"];
        var regexPattern = (string)contentAsJson["caseNumberPattern"];

        MatchCollection matches = Regex.Matches(textToSearch, regexPattern);

        var distinctMatches = matches.Cast<Match>().Select(x => x.Value).Distinct().ToList();

        JObject output = new JObject
        {
            ["MatchCount"] = distinctMatches.Count,
            ["CaseNumbers"] = JToken.FromObject(distinctMatches),
        };

        response = new HttpResponseMessage(HttpStatusCode.OK);
        response.Content = CreateJsonContent(output.ToString());
        return response;
    }

    // Run Web Form Routing Rules
    private async Task<HttpResponseMessage> RouteFormTaskToQueue()
    {
        try
        {
            string rawBody = await this.Context.Request.Content.ReadAsStringAsync();
            if(string.IsNullOrEmpty(rawBody))
                return Error(HttpStatusCode.BadRequest, "Request body is required");
            
            JObject body;
            try
            {
                body = JObject.Parse(rawBody);
            }
            catch
            {
                return Error(HttpStatusCode.BadRequest, "Invalid JSON in request body");
            }
            if (body["task"] == null || body["routingRules"] == null)
                return Error(HttpStatusCode.BadRequest, "Both 'task' and 'routingRules' are required.");

            string taskJson = body["task"].ToString();
            string rulesJson = body["routingRules"].ToString();

            var taskRecord = JsonConvert.DeserializeObject<TaskRecord>(taskJson);
            var routingRules = JsonConvert.DeserializeObject<List<RoutingRule>>(rulesJson);

            // Process rules and metadata
            var matchedRules = RuleProcessor.GetMatchedRules(routingRules, taskRecord.Metadata);

            string json = JsonConvert.SerializeObject(matchedRules);

            var response = new HttpResponseMessage(HttpStatusCode.OK);
            response.Content = CreateJsonContent(json);
            return response;
        }
        catch (Exception ex)
        {
            return Error(HttpStatusCode.InternalServerError, ex.Message);
        }
    }
    
    private HttpResponseMessage Error(HttpStatusCode status, string message)
    {
        string json = JsonConvert.SerializeObject(new 
        { 
            error = message,
            status = (int)status
        });

        var resp = new HttpResponseMessage(status);
        resp.Content = CreateJsonContent(json);
        return resp;
    }
}

// Data models for web form routing
public class TaskRecord
{
    [JsonProperty("activityid")]
    public string ActivityId { get; set; }

    [JsonProperty("tsk_webformmetadata")]
    public List<WebformMetadata> Metadata { get; set; }
}

public class WebformMetadata
{
    [JsonProperty("component_id")]
    public string ComponentId { get; set; }

    [JsonProperty("component_uuid")]
    public string ComponentUuid { get; set; }

    [JsonProperty("response")]
    public string Response { get; set; }

    [JsonProperty("item_uuid")]
    public string ItemUuid { get; set; }
}

public class RoutingRule
{
    [JsonProperty("tsk_routingrulesid")]
    public string Id { get; set; }

    [JsonProperty("tsk_rulename")]
    public string RuleName { get; set; }

    [JsonProperty("_tsk_sourcequeue_value")]
    public string SourceQueue { get; set; }

    [JsonProperty("_tsk_destinationqueue_value")]
    public string DestinationQueue { get; set; }

    [JsonProperty("tsk_webformconditions")]
    public ConditionRule Conditions { get; set; }
}

public class ConditionRule
{
    [JsonProperty("combinator")]
    public string Combinator { get; set; }

    [JsonProperty("component_uuid")]
    public string ComponentUuid { get; set; }

    [JsonProperty("item_uuid")]
    public string ItemUuid { get; set; }

    [JsonProperty("operator")]
    public string Operator { get; set; }

    [JsonProperty("rules")]
    public List<ConditionRule> Rules { get; set; }

    [JsonProperty("value")]
    public string Value { get; set; }
}

// Rule Evaluator
public class RuleEvaluator
{
    private readonly List<WebformMetadata> _metadata;

    public RuleEvaluator(List<WebformMetadata> metadata)
    {
        _metadata = metadata ?? new List<WebformMetadata>();
    }

    public bool Evaluate(ConditionRule rule)
    {
        bool isGroup =
            rule != null &&
            !string.IsNullOrEmpty(rule.Combinator) &&
            rule.Rules != null &&
            rule.Rules.Count > 0;

        return isGroup ? EvaluateGroup(rule) : EvaluateCondition(rule);
    }

    private bool EvaluateGroup(ConditionRule group)
    {
        bool isAnd = group.Combinator.Equals("and", StringComparison.OrdinalIgnoreCase);
        bool result = isAnd;

        foreach (var child in group.Rules)
        {
            bool childResult = Evaluate(child);
            result = isAnd ? (result && childResult) : (result || childResult);
        }

        return result;
    }

    private bool EvaluateCondition(ConditionRule cond)
    {
        if (string.IsNullOrEmpty(cond?.ComponentUuid))
            return false;

        var meta = _metadata.FirstOrDefault(m => m.ComponentUuid == cond.ComponentUuid);
        if (meta == null)
            return false;

        string left, right;

        bool metaHasItem = !string.IsNullOrEmpty(meta.ItemUuid);

        // Set Left/Right depending on radio-type question
        if (metaHasItem)
        {
            left = meta.ItemUuid ?? "";
            right = cond.ItemUuid ?? "";
        }
        else
        {
            left = meta.Response ?? "";
            right = cond.Value ?? "";
        }

        switch (cond.Operator)
        {
            case "=": return left.Equals(right, StringComparison.OrdinalIgnoreCase);
            case "!=": return !left.Equals(right, StringComparison.OrdinalIgnoreCase);
            case "Contains": return left.IndexOf(right ?? "", StringComparison.OrdinalIgnoreCase) >= 0;
            case "Does not contain": return left.IndexOf(right ?? "", StringComparison.OrdinalIgnoreCase) < 0;
            default: return false;
        }
    }
}

// Rule processor
public static class RuleProcessor
{
    public static List<RoutingRule> GetMatchedRules(
        List<RoutingRule> rules,
        List<WebformMetadata> metadata)
    {
        var evaluator = new RuleEvaluator(metadata);

        return (rules ?? new List<RoutingRule>())
            .Where(r => evaluator.Evaluate(r.Conditions))
            .ToList();
    }
}