using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;
using System.Net;
using System.Linq;

public class Script : ScriptBase
{
    public override async Task<HttpResponseMessage> ExecuteAsync()
    {
        if (this.Context.OperationId == "Regex")
        {
            return await this.PerformRegexMatch().ConfigureAwait(false);
        }

        HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.BadRequest);
        response.Content = CreateJsonContent($"Unknown operation ID '{this.Context.OperationId}'");
        return response;
    }

    private async Task<HttpResponseMessage> PerformRegexMatch()
    { 
        // Read body
        var requestContentString = await this.Context.Request.Content.ReadAsStringAsync().ConfigureAwait(false);
        var body = JObject.Parse(requestContentString);

        // Extract expected fields
        var inputString = (string)body["inputString"];
        var pattern     = (string)body["pattern"];

        if (string.IsNullOrWhiteSpace(inputString) || string.IsNullOrWhiteSpace(pattern))
        {
            var bad = new HttpResponseMessage(HttpStatusCode.BadRequest);
            bad.Content = CreateJsonContent("Both 'inputString' and 'pattern' are required.");
            return bad;
        }

        // Perform regex match
        MatchCollection matches;
        try
        {
            matches = Regex.Matches(inputString, pattern);
        }
        catch (System.Exception ex)
        {
            var err = new HttpResponseMessage(HttpStatusCode.BadRequest);
            err.Content = CreateJsonContent($"Invalid regex pattern: {ex.Message}");
            return err;
        }

        // Convert matches to JArray
        var resultArray = new JArray(matches.Cast<Match>().Select(m => m.Value));

        // Build response
        JObject output = new JObject
        {
            ["matches"] = resultArray
        };

        var response = new HttpResponseMessage(HttpStatusCode.OK);
        response.Content = CreateJsonContent(output.ToString());
        return response;
    }
}