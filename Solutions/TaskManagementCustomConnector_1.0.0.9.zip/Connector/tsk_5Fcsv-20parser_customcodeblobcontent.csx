using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

public class Script : ScriptBase
{
    public override async Task<HttpResponseMessage> ExecuteAsync()
    {
        string csvText;
        try
        {
            var raw = await this.Context.Request.Content.ReadAsStringAsync().ConfigureAwait(false);
            var json = JObject.Parse(raw);
            csvText = (string)json["CSV content"];
            if (string.IsNullOrEmpty(csvText))
                return Error(HttpStatusCode.BadRequest, "'CSV content' cannot be empty.");
        }
        catch (Exception ex)
        {
            return Error(HttpStatusCode.BadRequest, "Invalid JSON body: " + ex.Message);
        }

        try
        {
            // Normalize newlines
            string normalized = csvText.Replace("\r\n", "\n").Replace("\r", "\n");
            var rawLines = normalized.Split('\n');
            var lines = new System.Collections.Generic.List<string>();
            foreach (var ln in rawLines)
            {
                if (!string.IsNullOrWhiteSpace(ln))
                    lines.Add(ln);
            }

            if (lines.Count < 2)
                return Error(HttpStatusCode.BadRequest, "CSV must have one header row and at least one data row.");

            var headers = SplitCsvLine(lines[0]);

            // Build JSON objects for each data row
            var outputArray = new JArray();
            
            for (int r = 1; r < lines.Count; r++)
            {
                var values = SplitCsvLine(lines[r]);

                if (values.Count != headers.Count)
                    return Error(HttpStatusCode.BadRequest, $"Column mismatch on row {r + 1}.");

                var obj = new JObject();
                for (int c = 0; c < headers.Count; c++)
                {
                    string key = headers[c] ?? "";
                    string value = values[c] ?? "";
                    obj[key] = value;
                }
                outputArray.Add(obj);
            }

            var ok = new HttpResponseMessage(HttpStatusCode.OK);
            ok.Content = CreateJsonContent(outputArray.ToString());
            return ok;          

        }

        catch (Exception ex)
        {
            return Error(HttpStatusCode.BadRequest, "CSV parse error: " + ex.Message);
        }
    }

    private HttpResponseMessage Error(HttpStatusCode status, string message)
    {
        var resp = new HttpResponseMessage(status);
        resp.Content = CreateJsonContent(new JObject { ["error"] = message }.ToString());
        return resp;
    }


    private static System.Collections.Generic.List<string> SplitCsvLine(string line)
    {
        var result = new List<string>();
        var sb = new StringBuilder();
        bool inQuotes = false;

        for (int i = 0; i < line.Length; i++)
        {
            char c = line[i];

            if (c == '"')
            {
                if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                {
                    sb.Append('"');
                    i++;
                }
                else
                {
                    inQuotes = !inQuotes;
                }
            }
            else if (c == ',' && !inQuotes)
            {
                result.Add(sb.ToString());
                sb.Clear();
            }
            else
            {
                sb.Append(c);
            }
        }

        result.Add(sb.ToString());
        return result;
}
}